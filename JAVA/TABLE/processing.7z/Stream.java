package processing;

import java.util.ArrayList;
import java.util.List;
import java.awt.Image;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;

public class Stream{
	static List<RGB> rgbArray = new ArrayList<RGB>();
	public void stream(String fileName) throws IOException{
		Image ig = ImageIO.read(new File(fileName)); //TODO name image 
		int w = ig.getHeight(null);
		int h = ig.getWidth(null);
		Conversion blah = new Conversion();
		blah.imageProcessing(ig, 0, 0, w, h);
		
		PrintWriter buffer = null; 
		buffer = new PrintWriter("rgbvalues.txt"); 
		String temp = "";
		System.out.println("Buffer Write Begin"); //%TODO Remove this line
		for (int i = 0; i < rgbArray.size(); i++){
			temp = rgbArray.get(i).toString() + ",";
			buffer.print(temp);
		}
		buffer.close();
		System.out.println("Buffer Write end"); //%TODO remove this line
	}
}
